# `@solana/wallet-adapter-solong`

<!-- @TODO -->

Coming soon.