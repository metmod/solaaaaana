# `@solana/wallet-adapter-nightly`

<!-- @TODO -->

Coming soon.