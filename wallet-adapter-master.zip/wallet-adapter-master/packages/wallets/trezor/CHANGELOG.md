# @solana/wallet-adapter-trezor

## 0.1.2

### Patch Changes

-   ba90b65: Fix Trezor adapter on Firefox browsers

## 0.1.1

### Patch Changes

-   375e548: bump @trezor/connect-web to version 9.2.1

## 0.1.0

### Minor Changes

-   a9f41dde: Release Trezor adapter
