# `@solana/wallet-adapter-salmon`

<!-- @TODO -->

Coming soon.