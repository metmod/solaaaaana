# `@solana/wallet-adapter-xdefi`

<!-- @TODO -->

Coming soon.
