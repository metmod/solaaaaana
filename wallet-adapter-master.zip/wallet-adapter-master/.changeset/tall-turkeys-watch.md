---
'@solana/wallet-adapter-trust': patch
---

Update TrustWallet icon
