---
'@solana/wallet-adapter-keystone': patch
---

Add VersionedTransaction support to Keystone
