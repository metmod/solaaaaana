---
'@solana/wallet-adapter-trezor': patch
---

Update Trezor icon
